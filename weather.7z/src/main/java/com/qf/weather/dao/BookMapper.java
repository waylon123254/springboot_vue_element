package com.qf.weather.dao;

import com.qf.weather.bean.Book;

import java.util.List;

//Book类操作的映射接口
public interface BookMapper {

    //查询所有的表数据
    List<Book> findAll();

}
