package com.qf.weather.service;

import com.qf.weather.bean.Book;

import java.util.List;

public interface BookService {

    List<Book> findAll();
}
