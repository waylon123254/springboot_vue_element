package com.qf.weather.service.impl;

import com.qf.weather.bean.Book;
import com.qf.weather.dao.BookMapper;
import com.qf.weather.service.BookService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

/**
 * description:
 * author:姚哥
 * 公众号:java架构栈
 */
@Service
public class BookServiceImpl implements BookService {

    //依赖注入 相当于BookMapper mapper=new BookMapperImpl()
    @Resource
    BookMapper mapper;

    @Override
    public List<Book> findAll() {
        return mapper.findAll();
    }
}
