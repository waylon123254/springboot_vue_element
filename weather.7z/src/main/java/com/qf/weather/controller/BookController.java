package com.qf.weather.controller;

import com.qf.weather.bean.Book;
import com.qf.weather.service.BookService;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import java.util.List;

/**
 * description:
 * author:姚哥
 * 公众号:java架构栈
 */

// localhost:9999/book/list
@Controller
@RequestMapping("book")
public class BookController {

    //获得service
    @Resource
    BookService bookService;

    @RequestMapping("list")
    @ResponseBody
    public List<Book> bookList(){
        return bookService.findAll();
    }
}
