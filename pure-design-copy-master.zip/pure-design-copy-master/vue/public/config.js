export const serverIp = 'localhost'
