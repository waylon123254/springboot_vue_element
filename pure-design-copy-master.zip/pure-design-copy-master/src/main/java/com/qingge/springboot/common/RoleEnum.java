package com.qingge.springboot.common;

public enum RoleEnum {
    ROLE_ADMIN, ROLE_USER, ROLE_STUDENT, ROLE_TEACHER;
}
