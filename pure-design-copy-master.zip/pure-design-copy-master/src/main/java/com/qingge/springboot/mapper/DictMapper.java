package com.qingge.springboot.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.qingge.springboot.entity.Dict;

public interface DictMapper extends BaseMapper<Dict> {
}
