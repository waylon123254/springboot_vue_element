package com.wxk1991.mapper;

import com.wxk1991.entity.Admin;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 管理员 Mapper 接口
 * </p>
 *
 * @author jobob
 * @since 2021-12-25
 */
public interface AdminMapper extends BaseMapper<Admin> {

}
