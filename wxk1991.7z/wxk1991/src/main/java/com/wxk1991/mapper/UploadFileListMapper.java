package com.wxk1991.mapper;

import com.wxk1991.entity.UploadFileList;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author jobob
 * @since 2022-01-03
 */
public interface UploadFileListMapper extends BaseMapper<UploadFileList> {

}
