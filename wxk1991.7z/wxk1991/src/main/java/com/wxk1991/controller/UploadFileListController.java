package com.wxk1991.controller;


import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author jobob
 * @since 2022-01-03
 */
@RestController
@RequestMapping("/wxk1991/upload-file-list")
public class UploadFileListController {

}
