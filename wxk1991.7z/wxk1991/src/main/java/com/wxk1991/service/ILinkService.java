package com.wxk1991.service;

import com.wxk1991.entity.Link;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 友情连接 服务类
 * </p>
 *
 * @author jobob
 * @since 2021-12-20
 */
public interface ILinkService extends IService<Link> {

}
