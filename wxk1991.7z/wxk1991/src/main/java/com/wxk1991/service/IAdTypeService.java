package com.wxk1991.service;

import com.wxk1991.entity.AdType;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 广告类型 服务类
 * </p>
 *
 * @author jobob
 * @since 2021-12-20
 */
public interface IAdTypeService extends IService<AdType> {

}
