package com.wxk1991.service;

public class AddArticleInterface {
}
