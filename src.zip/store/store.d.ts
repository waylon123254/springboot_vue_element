import { Store } from 'vuex';

declare const store: Store<any>;
export default store;