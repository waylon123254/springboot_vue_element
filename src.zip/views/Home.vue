<template>
    <div>
        <h1>
            这是主页
        </h1>
    </div>
</template>
<script>
export default {
  name: "Home"
};
</script>
